import React, { useState, useEffect } from 'react';
import { StudentRecord, TrainingResult, ModelMetrics } from '../types';
import { trainTestSplit, trainLogisticRegression, trainDecisionTree, trainRandomForest, evaluateModel } from '../utils/machineLearning';
import { Cpu, Award, Zap, ChevronRight, BarChart3, Settings, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ModelTrainerProps {
  dataset: StudentRecord[];
  trainingResult: TrainingResult;
  setTrainingResult: (res: TrainingResult) => void;
  activeModelName: string;
  setActiveModelName: (name: string) => void;
}

export default function ModelTrainer({
  dataset,
  trainingResult,
  setTrainingResult,
  activeModelName,
  setActiveModelName
}: ModelTrainerProps) {
  // Hyperparameter states
  const [lrEpochs, setLrEpochs] = useState(800);
  const [lrLearningRate, setLrLearningRate] = useState(0.1);
  const [dtMaxDepth, setDtMaxDepth] = useState(4);
  const [rfTrees, setRfTrees] = useState(15);
  const [rfMaxDepth, setRfMaxDepth] = useState(4);
  const [showConfig, setShowConfig] = useState(false);

  // Split details overview
  const splitInfo = React.useMemo(() => {
    const split = trainTestSplit(dataset, 0.8);
    return {
      total: dataset.length,
      trainCount: split.train.X.length,
      testCount: split.test.X.length,
      trainPass: split.train.Y.filter(y => y === 1).length,
      trainFail: split.train.Y.filter(y => y === 0).length,
      testPass: split.test.Y.filter(y => y === 1).length,
      testFail: split.test.Y.filter(y => y === 0).length,
    };
  }, [dataset]);

  const handleTrainModels = () => {
    setTrainingResult({ ...trainingResult, isTraining: true });
    
    // Artificial 400ms delay to make it feel like real training is taking place (otherwise JS compiles in 2ms!)
    setTimeout(() => {
      try {
        const split = trainTestSplit(dataset, 0.8, 101);
        const { X: X_train, Y: Y_train } = split.train;
        const { X: X_test, Y: Y_test } = split.test;

        // 1. Train and evaluate Logistic Regression
        const lrModelRaw = trainLogisticRegression(X_train, Y_train, lrEpochs, lrLearningRate);
        const lrModel = evaluateModel(lrModelRaw, X_test, Y_test);

        // 2. Train and evaluate Decision Tree
        const dtModelRaw = trainDecisionTree(X_train, Y_train, dtMaxDepth);
        const dtModel = evaluateModel(dtModelRaw, X_test, Y_test);

        // 3. Train and evaluate Random Forest
        const rfModelRaw = trainRandomForest(X_train, Y_train, rfTrees, rfMaxDepth);
        const rfModel = evaluateModel(rfModelRaw, X_test, Y_test);

        // Find best model
        const lrAcc = lrModel.metrics.accuracy;
        const dtAcc = dtModel.metrics.accuracy;
        const rfAcc = rfModel.metrics.accuracy;

        let bestName = 'Random Forest Classifier';
        let maxAcc = rfAcc;
        if (lrAcc > maxAcc) {
          bestName = 'Logistic Regression';
          maxAcc = lrAcc;
        }
        if (dtAcc > maxAcc) {
          bestName = 'Decision Tree Classifier';
          maxAcc = dtAcc;
        }

        setTrainingResult({
          logisticRegression: lrModel,
          decisionTree: dtModel,
          randomForest: rfModel,
          bestModelName: bestName,
          isTraining: false
        });

      } catch (err) {
        console.error("Training error: ", err);
        setTrainingResult({ ...trainingResult, isTraining: false });
      }
    }, 450);
  };

  // Run initial training on load
  useEffect(() => {
    if (!trainingResult.logisticRegression) {
      handleTrainModels();
    }
  }, [dataset]);

  // Confusion Matrix cell renderer
  const renderConfusionMatrix = (metrics: ModelMetrics) => {
    const { tp, tn, fp, fn } = metrics.confusionMatrix;
    return (
      <div className="border border-slate-200 rounded-lg p-3 bg-slate-50 font-mono text-center">
        <div className="grid grid-cols-3 gap-1.5 text-[10px] font-bold text-slate-500 uppercase">
          <div></div>
          <div>Pred PASS</div>
          <div>Pred FAIL</div>
        </div>
        <div className="grid grid-cols-3 gap-1.5 items-center mt-1">
          <div className="text-[10px] font-bold text-slate-500 text-left">Act PASS</div>
          <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-md border border-emerald-100 font-bold" title="True Positives">
            {tp}
            <div className="text-[8px] font-normal text-emerald-500 font-sans">TP</div>
          </div>
          <div className="bg-red-50 text-red-800 p-1.5 rounded-md border border-red-100 font-bold" title="False Negatives">
            {fn}
            <div className="text-[8px] font-normal text-red-400 font-sans">FN</div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-1.5 items-center mt-1.5">
          <div className="text-[10px] font-bold text-slate-500 text-left">Act FAIL</div>
          <div className="bg-red-50 text-red-800 p-1.5 rounded-md border border-red-100 font-bold" title="False Positives">
            {fp}
            <div className="text-[8px] font-normal text-red-400 font-sans">FP</div>
          </div>
          <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-md border border-emerald-100 font-bold" title="True Negatives">
            {tn}
            <div className="text-[8px] font-normal text-emerald-500 font-sans">TN</div>
          </div>
        </div>
      </div>
    );
  };

  // Classification report renderer
  const renderClassificationReport = (metrics: ModelMetrics) => {
    const report = metrics.classificationReport;
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-600 border border-slate-100 rounded-lg overflow-hidden">
          <thead>
            <tr className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase border-b border-slate-100">
              <th className="py-1.5 px-3">Class Label</th>
              <th className="py-1.5 px-3">Precision</th>
              <th className="py-1.5 px-3">Recall</th>
              <th className="py-1.5 px-3">F1-Score</th>
              <th className="py-1.5 px-3 text-right">Support</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono">
            <tr>
              <td className="py-1.5 px-3 font-sans font-medium text-slate-800">Pass</td>
              <td className="py-1.5 px-3 text-emerald-600 font-medium">{(report.Pass.precision * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-emerald-600 font-medium">{(report.Pass.recall * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-emerald-600 font-medium">{(report.Pass.f1Score * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-slate-400 text-right">{report.Pass.support}</td>
            </tr>
            <tr>
              <td className="py-1.5 px-3 font-sans font-medium text-slate-800">Fail</td>
              <td className="py-1.5 px-3 text-indigo-600 font-medium">{(report.Fail.precision * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-indigo-600 font-medium">{(report.Fail.recall * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-indigo-600 font-medium">{(report.Fail.f1Score * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 text-slate-400 text-right">{report.Fail.support}</td>
            </tr>
            <tr className="bg-slate-50 font-sans font-medium">
              <td className="py-1.5 px-3 text-slate-800">Macro Avg</td>
              <td className="py-1.5 px-3 font-mono text-slate-700 font-semibold">{(report.macroAvg.precision * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 font-mono text-slate-700 font-semibold">{(report.macroAvg.recall * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 font-mono text-slate-700 font-semibold">{(report.macroAvg.f1Score * 100).toFixed(1)}%</td>
              <td className="py-1.5 px-3 font-mono text-slate-400 text-right">{report.macroAvg.support}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  const modelsArray = [
    { key: 'logisticRegression', title: 'Logistic Regression', desc: 'Binary probability classifier' },
    { key: 'decisionTree', title: 'Decision Tree Classifier', desc: 'Flowchart splits using Gini Criterion' },
    { key: 'randomForest', title: 'Random Forest Classifier', desc: 'Bootstrap aggregate ensemble prediction' }
  ];

  return (
    <div id="model-trainer" className="space-y-6">
      
      {/* Upper Pipeline Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Split Details Banner */}
        <div className="md:col-span-1 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900">1. Stratified Data Split</h3>
            <p className="text-xs text-slate-500">Separated at 80% train and 20% validation test ratio to evaluate generalization power.</p>
          </div>
          
          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-50">
              <span className="text-slate-500 font-sans">Full Dataset Count:</span>
              <span className="font-bold text-slate-800">{splitInfo.total} records</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-50 text-indigo-700 bg-indigo-50/40 px-2 rounded-lg">
              <span className="font-sans font-medium">Training Set (80%):</span>
              <span className="font-bold">{splitInfo.trainCount} rows</span>
            </div>
            <div className="pl-4 space-y-1 text-[10px] text-slate-550">
              <div className="flex justify-between">
                <span>Pass outcome weight:</span>
                <span>{splitInfo.trainPass} ({((splitInfo.trainPass / splitInfo.trainCount)*100).toFixed(1)}%)</span>
              </div>
              <div className="flex justify-between">
                <span>Fail outcome weight:</span>
                <span>{splitInfo.trainFail} ({((splitInfo.trainFail / splitInfo.trainCount)*100).toFixed(1)}%)</span>
              </div>
            </div>

            <div className="flex justify-between items-center py-1 border-b border-slate-50 text-emerald-700 bg-emerald-50/40 px-2 rounded-lg">
              <span className="font-sans font-medium">Test Set (20%):</span>
              <span className="font-bold">{splitInfo.testCount} rows</span>
            </div>
            <div className="pl-4 space-y-1 text-[10px] text-slate-550">
              <div className="flex justify-between">
                <span>Pass validation target:</span>
                <span>{splitInfo.testPass}</span>
              </div>
              <div className="flex justify-between">
                <span>Fail validation target:</span>
                <span>{splitInfo.testFail}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Hyperparameter Config and Action Trigger */}
        <div className="md:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-900">2. Hyperparameter Settings</h3>
                <p className="text-xs text-slate-500">Tune mathematical learning models to optimize diagnostic success scores.</p>
              </div>
              <button
                id="toggle-config-btn"
                onClick={() => setShowConfig(!showConfig)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-2.5 py-1.5 rounded-lg border border-indigo-100 transition-colors"
              >
                <Settings className="w-3.5 h-3.5" />
                {showConfig ? "Hide Hyperparameters" : "Show Hyperparameters"}
              </button>
            </div>

            {/* Sliding Controls Panel */}
            {showConfig && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 border border-slate-100 rounded-xl p-4 mt-2">
                
                {/* Logistic Reg Params */}
                <div className="space-y-3">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Logistic Regression</h4>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-semibold text-slate-600">Max Epochs:</span>
                      <span className="font-mono font-bold text-slate-800">{lrEpochs}</span>
                    </div>
                    <input
                      type="range" min="100" max="2000" step="100"
                      value={lrEpochs}
                      onChange={(e) => setLrEpochs(Number(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-semibold text-slate-600">Learning Rate:</span>
                      <span className="font-mono font-bold text-slate-800">{lrLearningRate.toFixed(2)}</span>
                    </div>
                    <input
                      type="range" min="0.01" max="0.5" step="0.01"
                      value={lrLearningRate}
                      onChange={(e) => setLrLearningRate(Number(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>

                {/* Decision Tree Params */}
                <div className="space-y-3 sm:border-l border-slate-200 sm:pl-4">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Decision Tree</h4>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-semibold text-slate-600">Max Depth Limit:</span>
                      <span className="font-mono font-bold text-slate-800">{dtMaxDepth} layers</span>
                    </div>
                    <input
                      type="range" min="1" max="10" step="1"
                      value={dtMaxDepth}
                      onChange={(e) => setDtMaxDepth(Number(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                  <p className="text-[10px] text-slate-450 leading-relaxed pt-2">
                    Deeper trees fit training details more exactly but risk overfitting validation data.
                  </p>
                </div>

                {/* Random Forest Params */}
                <div className="space-y-3 sm:border-l border-slate-200 sm:pl-4">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Random Forest</h4>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-semibold text-slate-600">Tree Estimators:</span>
                      <span className="font-mono font-bold text-slate-800">{rfTrees} trees</span>
                    </div>
                    <input
                      type="range" min="5" max="50" step="5"
                      value={rfTrees}
                      onChange={(e) => setRfTrees(Number(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="font-semibold text-slate-600">Tree Max Depth:</span>
                      <span className="font-mono font-bold text-slate-800">{rfMaxDepth} layers</span>
                    </div>
                    <input
                      type="range" min="1" max="10" step="1"
                      value={rfMaxDepth}
                      onChange={(e) => setRfMaxDepth(Number(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>

              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-slate-50">
            <div className="flex items-center gap-2 text-xs text-slate-505 font-medium">
              <AlertTriangle className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>Updating hyperparameters will recalibrate weights on click.</span>
            </div>
            <button
              id="train-models-btn"
              onClick={handleTrainModels}
              disabled={trainingResult.isTraining}
              className="w-full sm:w-auto px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2"
            >
              <Cpu className={`w-4 h-4 ${trainingResult.isTraining ? 'animate-spin' : ''}`} />
              {trainingResult.isTraining ? 'Fitting Classifiers...' : 'Train Models Live'}
            </button>
          </div>
        </div>

      </div>

      {/* Model Grid Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {modelsArray.map((modelMeta) => {
          const model = trainingResult[modelMeta.key as 'logisticRegression' | 'decisionTree' | 'randomForest'];
          const isBest = trainingResult.bestModelName === modelMeta.title;

          if (!model) return null;

          return (
            <div
              key={modelMeta.key}
              onClick={() => setActiveModelName(modelMeta.title)}
              className={`border rounded-2xl p-5 shadow-2xs transition-all cursor-pointer relative ${
                activeModelName === modelMeta.title
                  ? 'border-indigo-600 bg-indigo-50/5 ring-1 ring-indigo-600'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              {/* Best Model Badge Overlay */}
              {isBest && (
                <div className="absolute top-4 right-4 bg-amber-500 text-white flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider shadow-xs animate-pulse">
                  <Award className="w-3 h-3" /> Best Model
                </div>
              )}

              {/* Model Description Header */}
              <div className="space-y-1 mb-5">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${
                    model.type === 'logistic_regression' ? 'bg-indigo-600' : model.type === 'decision_tree' ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}></span>
                  {modelMeta.title}
                </h4>
                <p className="text-[11px] text-slate-500 leading-normal">{modelMeta.desc}</p>
              </div>

              {/* Key Score Block */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 text-center mb-5 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">Test Accuracy Score:</span>
                <span className={`text-2xl font-black font-mono tracking-tight ${
                  isBest ? 'text-amber-600' : 'text-slate-800'
                }`}>
                  {(model.metrics.accuracy * 100).toFixed(2)}%
                </span>
              </div>

              {/* Sub-matrices details */}
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Confusion Matrix</h5>
                  {renderConfusionMatrix(model.metrics)}
                </div>

                <div className="space-y-1.5">
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Classification Report</h5>
                  {renderClassificationReport(model.metrics)}
                </div>
              </div>

              {/* Active Selection Indicator */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Interactive prediction model</span>
                <span className={`font-bold transition-all flex items-center gap-0.5 ${
                  activeModelName === modelMeta.title ? 'text-indigo-600' : 'text-slate-400'
                }`}>
                  {activeModelName === modelMeta.title ? "Selected Playground" : "Click to select"}
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
