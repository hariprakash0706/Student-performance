import React, { useState, useMemo } from 'react';
import { StudentRecord, CleaningStats } from '../types';
import { generateSampleDataset, cleanDataset } from '../utils/dataGenerator';
import { Database, Filter, Search, RotateCcw, ShieldCheck, Check, AlertCircle, Heart, Trash2, ShieldAlert } from 'lucide-react';

interface DatasetExplorerProps {
  dataset: StudentRecord[];
  setDataset: (data: StudentRecord[]) => void;
  originalCount: number;
  setOriginalCount: (c: number) => void;
  cleaningStats: CleaningStats | null;
  setCleaningStats: (stats: CleaningStats | null) => void;
}

export default function DatasetExplorer({
  dataset,
  setDataset,
  originalCount,
  setOriginalCount,
  cleaningStats,
  setCleaningStats
}: DatasetExplorerProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'pass' | 'fail'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [dirtyMode, setDirtyMode] = useState(false);
  const itemsPerPage = 10;

  // Handles generating standard clean vs dirty data
  const handleRegenerate = (dirty: boolean) => {
    setDirtyMode(dirty);
    const rawData = generateSampleDataset(1998, dirty);
    setDataset(rawData);
    setOriginalCount(rawData.length);
    setCleaningStats(null); // Reset cleaning stats until "Clean Data" is triggered
    setCurrentPage(1);
  };

  // Perform Clean Data routine
  const handleCleanData = () => {
    const { cleanedData, stats } = cleanDataset(dataset);
    setDataset(cleanedData);
    setCleaningStats(stats);
    setCurrentPage(1);
  };

  // Reset entirely
  const handleResetAll = () => {
    setDirtyMode(false);
    const rawData = generateSampleDataset(1998, false);
    setDataset(rawData);
    setOriginalCount(rawData.length);
    setCleaningStats(null);
    setCurrentPage(1);
    setSearchTerm('');
    setActiveTab('all');
  };

  // Filter & Search dataset
  const filteredDataset = useMemo(() => {
    return dataset.filter(item => {
      // Result tab filtering
      if (activeTab === 'pass' && item.result !== 'Pass') return false;
      if (activeTab === 'fail' && item.result !== 'Fail') return false;

      // Text search matching
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const idMatch = item.id.toString().includes(query);
        const attMatch = item.attendance >= 0 ? item.attendance.toString().includes(query) : 'missing'.includes(query);
        const internalMatch = item.internalMarks >= 0 ? item.internalMarks.toString().includes(query) : 'missing'.includes(query);
        const assignmentMatch = item.assignmentScore >= 0 ? item.assignmentScore.toString().includes(query) : 'missing'.includes(query);
        const hoursMatch = item.studyHours >= 0 ? item.studyHours.toString().includes(query) : 'missing'.includes(query);
        const resultMatch = item.result.toLowerCase().includes(query);

        return idMatch || attMatch || internalMatch || assignmentMatch || hoursMatch || resultMatch;
      }

      return true;
    });
  }, [dataset, activeTab, searchTerm]);

  // Paginated records
  const paginatedData = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredDataset.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredDataset, currentPage]);

  const totalPages = Math.ceil(filteredDataset.length / itemsPerPage) || 1;

  // Descriptive statistics for the currently loaded records
  const stats = useMemo(() => {
    const validRecs = dataset.filter(d => d.attendance >= 0 && d.internalMarks >= 0 && d.assignmentScore >= 0 && d.studyHours >= 0);
    const count = validRecs.length;
    if (count === 0) return { passRate: 0, avgAttendance: 0, avgInternals: 0, avgHours: 0 };

    const passes = validRecs.filter(d => d.result === 'Pass').length;
    const passRate = (passes / count) * 100;
    const avgAttendance = validRecs.reduce((sum, d) => sum + d.attendance, 0) / count;
    const avgInternals = validRecs.reduce((sum, d) => sum + d.internalMarks, 0) / count;
    const avgHours = validRecs.reduce((sum, d) => sum + d.studyHours, 0) / count;

    return {
      passRate,
      avgAttendance,
      avgInternals,
      avgHours
    };
  }, [dataset]);

  return (
    <div id="dataset-explorer" className="space-y-6">
      
      {/* Control Banner */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Database className="w-5 h-5 text-indigo-600" />
              Dataset Management Panel
            </h2>
            <p className="text-xs text-slate-500">
              Generate seeded cohorts of 500+ records. Toggle raw anomalies to witness data pre-processing and target engineering live.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            <button
              id="generate-clean-btn"
              onClick={() => handleRegenerate(false)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                !dirtyMode && !cleaningStats
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              Generate Clean Cohort (N=500)
            </button>
            <button
              id="generate-dirty-btn"
              onClick={() => handleRegenerate(true)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                dirtyMode && !cleaningStats
                  ? 'bg-amber-50 border-amber-200 text-amber-700'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              Generate Dirty Cohort (N=508)
            </button>
            {dirtyMode && !cleaningStats && (
              <button
                id="clean-dataset-btn"
                onClick={handleCleanData}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Run Data Cleaning
              </button>
            )}
            <button
              id="reset-dataset-btn"
              onClick={handleResetAll}
              className="p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-500 hover:text-slate-800 transition-colors"
              title="Reset Dataset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Cleaning Pipeline Logs */}
        {cleaningStats && (
          <div className="bg-emerald-50/50 border border-emerald-100/80 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-2.5">
              <span className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg mt-0.5">
                <Check className="w-4 h-4" />
              </span>
              <div>
                <p className="text-xs font-bold text-emerald-900">Cleaning Log: Preprocessing Pipeline Completed Successfully</p>
                <p className="text-[11px] text-emerald-600 mt-0.5">
                  Handled missing attribute points using running numerical median values and dropped duplicate student signatures.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white/70 backdrop-blur-sm border border-emerald-100/50 rounded-lg p-2.5 text-center">
              <div className="px-2">
                <div className="text-xs font-mono font-bold text-slate-700">{cleaningStats.originalCount}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">Original Rows</div>
              </div>
              <div className="px-2 border-l border-slate-100">
                <div className="text-xs font-mono font-bold text-indigo-600">{cleaningStats.missingValuesHandled}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">Imputed Nulls</div>
              </div>
              <div className="px-2 border-l border-slate-100">
                <div className="text-xs font-mono font-bold text-red-600">{cleaningStats.duplicatesRemoved}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">Duplicates Dropped</div>
              </div>
              <div className="px-2 border-l border-slate-100">
                <div className="text-xs font-mono font-bold text-emerald-600">{cleaningStats.cleanedCount}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">Final Dataset</div>
              </div>
            </div>
          </div>
        )}

        {/* Informative Banner when dirty mode is active and uncleaned */}
        {dirtyMode && !cleaningStats && (
          <div className="bg-amber-50/70 border border-amber-100 rounded-xl p-4 flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-amber-900">Anomalous Points Detected!</p>
              <p className="text-[11px] text-amber-700 leading-relaxed mt-0.5">
                This cohort contains <b>8 duplicate records</b> and <b>8 missing values</b> (represented as negative indicators: <span className="font-mono bg-amber-100 px-1 rounded">-1</span>). Some machine learning models will produce biased values or fail to execute on missing values. Click <b>"Run Data Cleaning"</b> to resolve them.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Summary Stat Blocks */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200/70 rounded-2xl p-4 shadow-xs">
          <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Total Samples</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-0.5">{dataset.length}</div>
          <p className="text-[10px] text-slate-500 mt-1">Student records currently loaded</p>
        </div>
        <div className="bg-white border border-slate-200/70 rounded-2xl p-4 shadow-xs">
          <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Avg Attendance</div>
          <div className="text-xl font-bold text-indigo-600 font-mono mt-0.5">{stats.avgAttendance.toFixed(1)}%</div>
          <p className="text-[10px] text-slate-50  -500 mt-1">Healthy attendance average</p>
        </div>
        <div className="bg-white border border-slate-200/70 rounded-2xl p-4 shadow-xs">
          <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Class Pass Rate</div>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-0.5">{stats.passRate.toFixed(1)}%</div>
          <p className="text-[10px] text-slate-505 mt-1">Overall percentage of passing marks</p>
        </div>
        <div className="bg-white border border-slate-200/70 rounded-2xl p-4 shadow-xs">
          <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Average Study Commitment</div>
          <div className="text-xl font-bold text-amber-600 font-mono mt-0.5">{stats.avgHours.toFixed(1)} hr</div>
          <p className="text-[10px] text-slate-450 mt-1">Daily hours of dedicated self-study</p>
        </div>
      </div>

      {/* Dataset Table Structure */}
      <div className="bg-white border border-slate-200/90 rounded-2xl shadow-sm overflow-hidden">
        
        {/* Table Controls (Search, Tabs) */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
            <button
              onClick={() => { setActiveTab('all'); setCurrentPage(1); }}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              All Records ({dataset.length})
            </button>
            <button
              onClick={() => { setActiveTab('pass'); setCurrentPage(1); }}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
                activeTab === 'pass'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Pass ({dataset.filter(d => d.result === 'Pass').length})
            </button>
            <button
              onClick={() => { setActiveTab('fail'); setCurrentPage(1); }}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
                activeTab === 'fail'
                  ? 'bg-red-600 text-white'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Fail ({dataset.filter(d => d.result === 'Fail').length})
            </button>
          </div>

          <div className="relative max-w-xs w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search table values..."
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              className="w-full pl-9 pr-4 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors placeholder:text-slate-400 text-slate-800"
            />
          </div>
        </div>

        {/* Data Grid Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-150 text-[11px] font-bold text-slate-550 uppercase bg-slate-50 tracking-wider">
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4">Attendance Rate</th>
                <th className="py-3 px-4">Internal Marks</th>
                <th className="py-3 px-4">Assignment Score</th>
                <th className="py-3 px-4">Study Hours / Day</th>
                <th className="py-13 px-4 text-center">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {paginatedData.length > 0 ? (
                paginatedData.map((student) => {
                  const isAttMissing = student.attendance < 0;
                  const isInternalMissing = student.internalMarks < 0;
                  const isAssignMissing = student.assignmentScore < 0;
                  const isHoursMissing = student.studyHours < 0;

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-2.5 px-4 font-mono font-medium text-slate-500">
                        #{student.id.toString().padStart(3, '0')}
                      </td>
                      
                      {/* Attendance Cell */}
                      <td className="py-2.5 px-4">
                        {isAttMissing ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded text-[10px] font-medium font-mono">
                            <ShieldAlert className="w-3 h-3" /> MISSING
                          </span>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="font-mono">{student.attendance}%</span>
                            <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden hidden sm:block">
                              <div
                                className={`h-full rounded-full ${student.attendance >= 75 ? 'bg-indigo-600' : 'bg-red-500'}`}
                                style={{ width: `${student.attendance}%` }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Internal Marks Cell */}
                      <td className="py-2.5 px-4 font-mono">
                        {isInternalMissing ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded text-[10px] font-medium font-mono">
                            <ShieldAlert className="w-3 h-3" /> MISSING
                          </span>
                        ) : (
                          `${student.internalMarks} / 50`
                        )}
                      </td>

                      {/* Assignment Score Cell */}
                      <td className="py-2.5 px-4 font-mono">
                        {isAssignMissing ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded text-[10px] font-medium font-mono">
                            <ShieldAlert className="w-3 h-3" /> MISSING
                          </span>
                        ) : (
                          `${student.assignmentScore}%`
                        )}
                      </td>

                      {/* Study Hours Cell */}
                      <td className="py-2.5 px-4 font-mono">
                        {isHoursMissing ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded text-[10px] font-medium font-mono">
                            <ShieldAlert className="w-3 h-3" /> MISSING
                          </span>
                        ) : (
                          `${student.studyHours} hr`
                        )}
                      </td>

                      {/* Outcomes Cell */}
                      <td className="py-2.5 px-4 text-center">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase ${
                          student.result === 'Pass'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {student.result}
                        </span>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                    No records found matching the search key.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer / Pagination */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-between text-xs font-medium text-slate-500 bg-slate-50/50">
          <div>
            Showing <span className="text-slate-800">{filteredDataset.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}</span> to <span className="text-slate-800">{Math.min(currentPage * itemsPerPage, filteredDataset.length)}</span> of <span className="text-slate-800">{filteredDataset.length}</span> students
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <span className="px-3 py-1 font-mono text-slate-700">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
