import React, { useState, useMemo } from 'react';
import { TrainingResult } from '../types';
import { Sparkles, BarChart2, ShieldCheck, ThumbsUp, ShieldAlert, GraduationCap, ArrowRight } from 'lucide-react';

interface PredictorPlaygroundProps {
  trainingResult: TrainingResult;
  activeModelName: string;
  setActiveModelName: (name: string) => void;
}

export default function PredictorPlayground({
  trainingResult,
  activeModelName,
  setActiveModelName
}: PredictorPlaygroundProps) {
  
  // Feature states
  const [attendance, setAttendance] = useState(82);
  const [internalMarks, setInternalMarks] = useState(32);
  const [assignmentScore, setAssignmentScore] = useState(75);
  const [studyHours, setStudyHours] = useState(5.2);

  const activeModel = useMemo(() => {
    if (activeModelName === 'Logistic Regression') return trainingResult.logisticRegression;
    if (activeModelName === 'Decision Tree Classifier') return trainingResult.decisionTree;
    return trainingResult.randomForest;
  }, [activeModelName, trainingResult]);

  // Compute live prediction
  const prediction = useMemo(() => {
    if (!activeModel) return { label: 'Pass' as const, probability: 0.5 };
    return activeModel.predict({
      attendance,
      internalMarks,
      assignmentScore,
      studyHours
    });
  }, [activeModel, attendance, internalMarks, assignmentScore, studyHours]);

  // Procedural prescription feedback
  const dynamicPrescription = useMemo(() => {
    const isPass = prediction.label === 'Pass';
    const prob = prediction.probability * 100;
    
    const recommendations: string[] = [];

    // Trigger specific feedback based on slider states
    if (attendance < 75) {
      recommendations.push(`Attendance is critically low (${attendance}%). Standard class policies mandate a minimum of 75% attendance. Advise student to attend consecutive supplementary sessions.`);
    }

    if (internalMarks < 25) {
      recommendations.push(`Continuous evaluation internal marks is failing (${internalMarks}/50). Student should unlock credit recoveries or complete diagnostic revision sets.`);
    }

    if (studyHours < 4.0) {
      recommendations.push(`Daily self-study of ${studyHours} hours is below average. Urge student to allocate at least 1.5 hours of dedicated additional review time.`);
    }

    if (isPass && prob < 75) {
      recommendations.push("Student is in a borderline passing tier. Ensure assignment scores maintain above 80% to avoid mid-phase drop-offs.");
    }

    if (isPass && prob >= 75) {
      recommendations.push("Student reflects secure performance parameters. Suggest continuation of active habits and Peer tutoring guidance!");
    }

    if (!isPass && recommendations.length === 0) {
      recommendations.push("Slightly augment self-study commitment or secure +4 points on upcoming test metrics to transition to a Passing outcome.");
    }

    return {
      statusClass: isPass ? 'text-emerald-700 bg-emerald-50 border-emerald-100' : 'text-red-700 bg-red-50 border-red-100',
      recommendations
    };
  }, [prediction, attendance, internalMarks, studyHours]);

  return (
    <div id="predictor-playground" className="space-y-6">
      
      {/* Selection row */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h4 className="text-xs font-bold text-slate-450 uppercase tracking-widest font-mono">Prediction Engine</h4>
          <span className="text-sm font-bold text-slate-800">Select Active Testing Algorithm:</span>
        </div>
        
        <div className="flex flex-wrap gap-1.5 bg-slate-100 border border-slate-200/50 rounded-xl p-1">
          {['Logistic Regression', 'Decision Tree Classifier', 'Random Forest Classifier'].map((mName) => (
            <button
              key={mName}
              onClick={() => setActiveModelName(mName)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                activeModelName === mName
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              {mName.split(' ')[0]} {mName.includes('Forest') ? 'Forest' : mName.includes('Tree') ? 'Tree' : 'LR'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Inputs Portion Grid (Cols 7) */}
        <div className="lg:col-span-7 space-y-6 bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900">Student Feature Parameters</h3>
            <p className="text-xs text-slate-500">Tune the sliding dimensions below to formulate real-time simulation predictions.</p>
          </div>

          <div className="space-y-6 pt-2">
            
            {/* Dimension 1: Attendance */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                  Attendance Percentage
                </span>
                <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-150">
                  {attendance}%
                </span>
              </div>
              <input
                type="range" min="30" max="100" step="1"
                value={attendance}
                onChange={(e) => setAttendance(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-450">
                <span>Critical: &lt;75%</span>
                <span>Satisfactory: 75% - 85%</span>
                <span>Excellent: &gt;85%</span>
              </div>
            </div>

            {/* Dimension 2: Internal Marks */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Continuous Internal Marks
                </span>
                <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-150">
                  {internalMarks} / 50
                </span>
              </div>
              <input
                type="range" min="0" max="50" step="1"
                value={internalMarks}
                onChange={(e) => setInternalMarks(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <div className="flex justify-between text-[10px] text-slate-450">
                <span>Fail Limit: &lt;20</span>
                <span>Average: 20 - 35</span>
                <span>Outstanding: &gt;35</span>
              </div>
            </div>

            {/* Dimension 3: Assignment Score */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  Assignment Completion Score
                </span>
                <span className="font-mono font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-150">
                  {assignmentScore}%
                </span>
              </div>
              <input
                type="range" min="0" max="100" step="1"
                value={assignmentScore}
                onChange={(e) => setAssignmentScore(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[10px] text-slate-450">
                <span>Incomplete: &lt;50%</span>
                <span>Moderate: 50% - 80%</span>
                <span>Complete: &gt;80%</span>
              </div>
            </div>

            {/* Dimension 4: Study Hours */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  Daily Self-Study Hours
                </span>
                <span className="font-mono font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-lg border border-purple-150">
                  {studyHours} hr/day
                </span>
              </div>
              <input
                type="range" min="0.5" max="12" step="0.1"
                value={studyHours}
                onChange={(e) => setStudyHours(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-purple-600"
              />
              <div className="flex justify-between text-[10px] text-slate-450">
                <span>Sub-average: &lt;3hr</span>
                <span>Moderate Study: 3 - 6hr</span>
                <span>Intense Focus: &gt;6hr</span>
              </div>
            </div>

          </div>
        </div>

        {/* Right Output Assessment Grid (Cols 5) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Main Predict Gauge card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white text-center relative overflow-hidden flex flex-col justify-between h-full min-h-[380px]">
            <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl"></div>

            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 font-mono">Live Diagnostic Outcome</span>
              <p className="text-xs text-slate-500 italic">via {activeModelName}</p>
            </div>

            {/* Micro Radial Gauge */}
            <div className="my-6 relative flex items-center justify-center">
              <svg className="w-40 h-40 transform -rotate-90">
                <circle
                  cx="80" cy="80" r="68"
                  className="stroke-slate-800 fill-none"
                  strokeWidth="10"
                />
                <circle
                  cx="80" cy="80" r="68"
                  className={`fill-none transition-all duration-300 ${
                    prediction.label === 'Pass' ? 'stroke-emerald-500' : 'stroke-red-500'
                  }`}
                  strokeWidth="10"
                  strokeDasharray={`${2 * Math.PI * 68}`}
                  strokeDashoffset={`${2 * Math.PI * 68 * (1 - prediction.probability)}`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className={`text-4xl font-extrabold tracking-tight ${
                  prediction.label === 'Pass' ? 'text-emerald-400' : 'text-red-400'
                }`}>
                  {prediction.label}
                </span>
                <span className="text-xs text-slate-400 font-mono mt-1">
                  {(prediction.probability * 100).toFixed(1)}% prob
                </span>
              </div>
            </div>

            {/* Summary Tagging Text */}
            <div className="space-y-3 relative">
              <div className={`border rounded-xl p-3 text-xs leading-relaxed ${dynamicPrescription.statusClass}`}>
                {prediction.label === 'Pass' ? (
                  <p className="font-semibold flex items-center justify-center gap-1 text-[11px]">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    Student predicted to SUCCEED and pass examinations.
                  </p>
                ) : (
                  <p className="font-semibold flex items-center justify-center gap-1 text-[11px]">
                    <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
                    Student flagged for academic UNDERPERFORMANCE risk.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Recommended Prescription Block */}
      <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-5 shadow-sm space-y-3">
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          Data-Driven Academic Recommendations & Guidance
        </h4>
        <div className="divide-y divide-slate-100 text-xs text-slate-600">
          {dynamicPrescription.recommendations.map((rec, index) => (
            <div key={index} className="py-2.5 flex items-start gap-2 text-slate-650">
              <ArrowRight className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
              <span>{rec}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
