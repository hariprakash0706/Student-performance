import { useState } from 'react';
import { Copy, Check, FileCode, BookOpen, Settings, CheckCircle2, TrendingUp } from 'lucide-react';

export default function DocumentationTab() {
  const [copied, setCopied] = useState(false);

  const pythonCode = `import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# 1. Procedural Sample Data Generation (500 records)
np.random.seed(42)
n_students = 500

# Generating academic features based on Gaussian distributions
attendance = np.clip(np.random.normal(78, 12, n_students).round(), 30, 100)
internal_marks = np.clip(np.random.normal(30, 8, n_students).round(), 0, 50)
assignment_score = np.clip(np.random.normal(72, 14, n_students).round(), 0, 100)
study_hours = np.clip(np.random.normal(4.8, 2.1, n_students).round(1), 0.5, 12.0)

# Target formula: P(Pass) is sigmoid function of linear features + noise
z = 0.09 * attendance + 0.16 * internal_marks + 0.04 * assignment_score + 0.45 * study_hours - 18.0
prob_pass = 1 / (1 + np.exp(-z))
noise = np.random.uniform(-0.05, 0.05, n_students)
test_threshold = prob_pass + noise
result = np.where(test_threshold >= 0.5, 'Pass', 'Fail')

# Construct Pandas DataFrame
raw_df = pd.DataFrame({
    'Attendance': attendance,
    'InternalMarks': internal_marks,
    'AssignmentScore': assignment_score,
    'StudyHours': study_hours,
    'Result': result
})

# 2. Data Cleaning & Exploration
print("--- DATA EXPLORATION ---")
print(raw_df.info())
print("\\nFirst 5 rows:")
print(raw_df.head())
print("\\nLast 5 rows:")
print(raw_df.tail())

# Handle duplicates and missing values if any
cleaned_df = raw_df.drop_duplicates()
print(f"\\nRemoved {len(raw_df) - len(cleaned_df)} duplicate records.")

# 3. Feature Selection
X = cleaned_df[['Attendance', 'InternalMarks', 'AssignmentScore', 'StudyHours']]
y = cleaned_df['Result'].apply(lambda x: 1 if x == 'Pass' else 0)

# 4. Train-Test Split (80/20)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=101, stratify=y)

# Normalize features (MinMax scaling for Logistic Regression stability)
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. Model Selection & Training
print("\\n--- MODEL TRAINING ---")
# Logistic Regression
lr_model = LogisticRegression(random_state=42)
lr_model.fit(X_train_scaled, y_train)
y_pred_lr = lr_model.predict(X_test_scaled)
acc_lr = accuracy_score(y_test, y_pred_lr)

# Decision Tree Classifier
dt_model = DecisionTreeClassifier(max_depth=4, random_state=42)
dt_model.fit(X_train, y_train)  # Trees don't strictly require scaling
y_pred_dt = dt_model.predict(X_test)
acc_dt = accuracy_score(y_test, y_pred_dt)

# Random Forest Classifier
rf_model = RandomForestClassifier(n_estimators=50, max_depth=4, random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
acc_rf = accuracy_score(y_test, y_pred_rf)

print(f"Logistic Regression Accuracy: {acc_lr:.4f}")
print(f"Decision Tree Accuracy:        {acc_dt:.4f}")
print(f"Random Forest Accuracy:       {acc_rf:.4f}")

# Find best model
accuracies = {
    'Logistic Regression': acc_lr,
    'Decision Tree': acc_dt,
    'Random Forest': acc_rf
}
best_model_name = max(accuracies, key=accuracies.get)
print(f"\\nBest Performing Model: {best_model_name}")

# 6. Evaluation Reports (Best Model)
best_model = None
y_pred_best = None
if best_model_name == 'Logistic Regression':
    best_model = lr_model
    y_pred_best = y_pred_lr
    X_eval = X_test_scaled
elif best_model_name == 'Decision Tree':
    best_model = dt_model
    y_pred_best = y_pred_dt
    X_eval = X_test
else:
    best_model = rf_model
    y_pred_best = y_pred_rf
    X_eval = X_test

print(f"\\n--- EVALUATION REPORT FOR {best_model_name.upper()} ---")
print("Confusion Matrix:")
cm = confusion_matrix(y_test, y_pred_best)
print(cm)
print("\\nClassification Report:")
print(classification_report(y_test, y_pred_best, target_names=['Fail', 'Pass']))

# 7. Data Visualization
print("\\nGenerating charts with Matplotlib...")

plt.figure(figsize=(12, 10))

# Plot 1: Accuracy Comparison Chart
plt.subplot(2, 2, 1)
model_names = list(accuracies.keys())
model_accs = [accuracies[m] * 100 for m in model_names]
bars = plt.bar(model_names, model_accs, color=['#4F46E5', '#10B981', '#F59E0B'])
plt.ylabel('Accuracy (%)')
plt.title('Algorithm Accuracy Comparison')
plt.ylim(60, 100)
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2.0, yval + 1, f'{yval:.2f}%', ha='center', va='bottom')

# Plot 2: Feature Importance (Random Forest as proxy)
plt.subplot(2, 2, 2)
importances = rf_model.feature_importances_
features_list = X.columns
y_pos = np.arange(len(features_list))
plt.barh(y_pos, importances, align='center', color='#8B5CF6')
plt.yticks(y_pos, features_list)
plt.xlabel('Importance Weight')
plt.title('Random Forest Feature Importance')

# Plot 3: Attendance vs Result (Jitter Scatter)
plt.subplot(2, 2, 3)
jitter = np.random.uniform(-0.15, 0.15, len(cleaned_df))
colors = cleaned_df['Result'].apply(lambda r: '#10B981' if r == 'Pass' else '#EF4444')
plt.scatter(cleaned_df['Attendance'], cleaned_df['StudyHours'] + jitter, c=colors, alpha=0.6, edgecolors='none')
plt.xlabel('Attendance %')
plt.ylabel('Study Hours / Day')
plt.title('Attendance & Study Hours vs Result\\n(Green=Pass, Red=Fail)')

# Plot 4: Internal Marks vs Result (Histogram Stack)
plt.subplot(2, 2, 4)
plt.hist([cleaned_df[cleaned_df['Result'] == 'Pass']['InternalMarks'], 
          cleaned_df[cleaned_df['Result'] == 'Fail']['InternalMarks']], 
         bins=15, stacked=True, color=['#10B981', '#EF4444'], label=['Pass', 'Fail'], alpha=0.7)
plt.xlabel('Internal Marks')
plt.ylabel('Student Count')
plt.title('Internal Marks Distribution by Result')
plt.legend()

plt.tight_layout()
plt.savefig('ml_plots.png')
print("Successfully saved visualizations to 'ml_plots.png'!")

# 8. Interactive Prediction Playground (Mock Example)
print("\\n--- SAMPLE INFERENCE ---")
sample_student = [[85, 42, 88, 6.5]] # [Attendance, InternalMarks, AssignmentScore, StudyHours]
# Standard prediction
pred = rf_model.predict(sample_student)
pred_prob = rf_model.predict_proba(sample_student)
print(f"Sample Input: Attendance=85%, Internals=42/50, Assignment=88%, StudyHours=6.5")
result_label = 'Pass' if pred[0] == 1 else 'Fail'
print(f"Prediction Result: {result_label} (Pass Probability: {pred_prob[0][1]*100:.2f}%)")
`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="documentation-tab" className="space-y-8">
      {/* Overview Block */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 text-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="relative">
          <div className="flex items-center gap-3 mb-4">
            <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
              <BookOpen className="w-6 h-6" />
            </span>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white">Project Report</h1>
          </div>
          <p className="text-slate-400 text-sm md:text-base leading-relaxed max-w-3xl">
            This module represents a comprehensive academic overview of the student success predictor machine learning task. Explore the core theoretical foundations, procedural split design pipelines, classification algorithms, and extract the matching Python source code for offline terminal operations.
          </p>
        </div>
      </div>

      {/* Grid of details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left two columns: The text explanation */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Section 1: Problem statement & goals */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-indigo-600 rounded-full"></span>
              1. Problem Statement & Research Objectives
            </h2>
            <div className="space-y-3 text-sm text-slate-600 leading-relaxed">
              <p>
                In academic institutions, educational progression analysis is key to proactive student mentorship. Early warning systems can reliably target underperforming students before dynamic term-end exams, reducing dropouts and failure rates.
              </p>
              <p className="font-medium text-slate-800">Objectives:</p>
              <ul className="list-disc pl-5 space-y-1 text-slate-600">
                <li>Procedurally synthesize a 500-student diagnostic dataset tracing academic indicator points.</li>
                <li>Clean and standardize variables to inspect feature correlations and remove noise indicators.</li>
                <li>Evaluate three key models: Logistic Regression, Decision Trees, and Random Forest.</li>
                <li>Establish an interactive predictive portal mapping feature coordinates directly to pass probability.</li>
              </ul>
            </div>
          </div>

          {/* Section 2: Data & Methodology */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-indigo-600 rounded-full"></span>
              2. Data Schema & Feature Engineering
            </h2>
            <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
              <p>
                The dataset consists of 500 generated rows, capturing realistic relationships where academic results are calculated based on effort and continuous evaluation values:
              </p>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50 text-xs font-semibold text-slate-500">
                      <th className="py-2 px-3">Feature Name</th>
                      <th className="py-2 px-3">Type</th>
                      <th className="py-2 px-3">Scale Range</th>
                      <th className="py-2 px-3">Scientific Significance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                    <tr>
                      <td className="py-2 px-3 font-mono text-indigo-600">Attendance</td>
                      <td className="py-2 px-3">Numerical</td>
                      <td className="py-2 px-3">30% to 100%</td>
                      <td className="py-2 px-3">Continuous presence proxy, maps directly to class interaction indices.</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono text-indigo-600">InternalMarks</td>
                      <td className="py-2 px-3">Numerical</td>
                      <td className="py-2 px-3">0 to 50</td>
                      <td className="py-2 px-3">Mid-term evaluation scores capturing preliminary subject mastery.</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono text-indigo-600">AssignmentScore</td>
                      <td className="py-2 px-3">Numerical</td>
                      <td className="py-2 px-3">0 to 100</td>
                      <td className="py-2 px-3">Measures routine participation and homework precision.</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono text-indigo-600">StudyHours</td>
                      <td className="py-2 px-3">Numerical</td>
                      <td className="py-2 px-3">0.5 to 12.0 / Day</td>
                      <td className="py-2 px-3">Out-of-class commitment mapping individual diligence metrics.</td>
                    </tr>
                    <tr className="bg-slate-50/50">
                      <td className="py-2 px-3 font-mono text-emerald-600 font-semibold">Result</td>
                      <td className="py-2 px-3 text-emerald-600 font-semibold">Categorical</td>
                      <td className="py-2 px-3 text-emerald-600 font-semibold">Pass / Fail</td>
                      <td className="py-2 px-3 text-emerald-600 font-semibold">Target label indicating progression success (Sigmoid Threshold).</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <p>
                <strong>Methodology Pipeline:</strong> 1. Data Collection & Simulation &rarr; 2. Preprocessing & Null Median Filling &rarr; 3. Normalization Mapping &rarr; 4. Train/Test Stratified Split (80/20) &rarr; 5. Multi-Classifier Training &rarr; 6. Evaluation Matrix Plotting.
              </p>
            </div>
          </div>

          {/* Section 3: Algorithms Used */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-indigo-600 rounded-full"></span>
              3. Deep-Dive: Classification Algorithms
            </h2>
            <div className="space-y-4">
              <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/50">
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-indigo-150 text-indigo-700 text-xs rounded font-mono">Model A</span>
                  Logistic Regression
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  Logistic Regression models the probability of a binary target variable using the logistic sigmoid function. In our browser runner, we evaluate the gradient of loss and optimize weights dynamically: 
                  <code className="block bg-white p-2 border border-slate-100 rounded font-mono text-[11px] text-slate-705 mt-1.5">
                    P(Pass) = 1 / (1 + exp(-(W・X + B)))
                  </code>
                  This functions best when inputs are standard min-max scaled to prevent scale dimensions (e.g., Assignment of 100 vs Study Hours of 2) from introducing unstable descent gradients.
                </p>
              </div>

              <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/50">
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-emerald-150 text-emerald-700 text-xs rounded font-mono">Model B</span>
                  Decision Tree Classifier
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  Decision Trees recursively partition data by finding feature coordinates and thresholds that maximize Gini impurity decrease (Gini Gain):
                  <code className="block bg-white p-2 border border-slate-100 rounded font-mono text-[11px] text-slate-705 mt-1.5">
                    Gini(Node) = 1 - p(Pass)² - p(Fail)²
                  </code>
                  This tree doesn't require scaling, resolves non-linear boundary rules, and offers brilliant explainability through node-splitting coefficients.
                </p>
              </div>

              <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/50">
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-amber-150 text-amber-700 text-xs rounded font-mono">Model C</span>
                  Random Forest Classifier
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  An ensemble technique that compiles a squad of decision tree models. Random Forest boosts model generalization by applying bootstrap aggregation (bagging) over random portions of training data. Feature ratings are consolidated across the forest ensemble, dropping individual variance and ensuring rugged robustness against overfitting.
                </p>
              </div>
            </div>
          </div>

          {/* Section 4: Future Enhancements */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-indigo-600 rounded-full"></span>
              4. Core Conclusions & Next Steps
            </h2>
            <div className="text-sm text-slate-600 space-y-3 leading-relaxed">
              <p>
                Our modeling benchmarks show that <strong>Internal Marks</strong> and <strong>Attendance</strong> form the strongest predictive factors for determining student outcomes. Early intervention based on combined values should target students with Attendance falls below 75% or Internal Marks below 25.
              </p>
              <p className="font-semibold text-slate-800">Future Enhancements Pipeline:</p>
              <ul className="list-decimal pl-5 space-y-1 text-xs">
                <li>Deploy continuous learning pipelines connecting student information servers live.</li>
                <li>Incorporate student demographic indicators, mental well-being scores, and socio-economic variables to capture non-academic metrics.</li>
                <li>Support Deep Neural Networks (using TensorFlow or PyTorch) to identify complex non-linear combinations.</li>
                <li>Configure automated SMS alerts to advisors and students directly when risk flags elevate.</li>
              </ul>
            </div>
          </div>

        </div>

        {/* Right column: Source code section with absolute copy feature */}
        <div id="python-source" className="lg:col-span-1 space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl shadow-xl overflow-hidden sticky top-6">
            
            {/* Header copy */}
            <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-indigo-400" />
                <span className="text-xs font-semibold text-white font-mono">predict_model.py</span>
              </div>
              <button
                id="copy-code-btn"
                onClick={copyToClipboard}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800/85 hover:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-700/50 transition-colors"
                title="Copy code to clipboard"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code scroll section */}
            <div className="p-4 max-h-[600px] overflow-y-auto custom-scrollbar">
              <pre className="text-[11px] text-slate-350 font-mono leading-relaxed whitespace-pre overflow-x-auto">
                <code>{pythonCode}</code>
              </pre>
            </div>

            {/* Explanatory footer */}
            <div className="bg-slate-900/40 p-4 border-t border-slate-800/80 text-xs text-slate-400 space-y-2">
              <p className="font-semibold text-white">How to execute locally:</p>
              <ol className="list-decimal pl-4 space-y-1 text-[11px]">
                <li>Create a clean virtual environment or open Terminal.</li>
                <li>Install library dependencies:<br />
                  <code className="bg-slate-900 text-slate-200 px-1 py-0.5 rounded text-[10px] select-all font-mono block mt-1">
                    pip install numpy pandas scikit-learn matplotlib
                  </code>
                </li>
                <li>Save this file as <span className="text-indigo-300 font-mono">predict_model.py</span>.</li>
                <li>Run command:<br />
                  <code className="bg-slate-900 text-slate-200 px-1 py-0.5 rounded text-[10px] select-all font-mono block mt-1">
                    python predict_model.py
                  </code>
                </li>
              </ol>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
