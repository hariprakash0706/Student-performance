import React, { useMemo } from 'react';
import { StudentRecord, TrainedModel, TrainingResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { BarChart3, TrendingUp, Info } from 'lucide-react';

interface VisualizationsProps {
  dataset: StudentRecord[];
  trainingResult: TrainingResult;
  activeModelName: string;
}

export default function Visualizations({
  dataset,
  trainingResult,
  activeModelName
}: VisualizationsProps) {
  
  // 1. Accuracy comparison data
  const accuracyData = useMemo(() => {
    return [
      {
        name: 'Logistic Regression',
        Accuracy: trainingResult.logisticRegression ? Math.round(trainingResult.logisticRegression.metrics.accuracy * 1000) / 10 : 80,
        fill: '#4F46E5'
      },
      {
        name: 'Decision Tree',
        Accuracy: trainingResult.decisionTree ? Math.round(trainingResult.decisionTree.metrics.accuracy * 1000) / 10 : 82,
        fill: '#10B981'
      },
      {
        name: 'Random Forest',
        Accuracy: trainingResult.randomForest ? Math.round(trainingResult.randomForest.metrics.accuracy * 1000) / 10 : 85,
        fill: '#F59E0B'
      }
    ];
  }, [trainingResult]);

  // 2. Feature Importance data from active model
  const activeModel = useMemo(() => {
    if (activeModelName === 'Logistic Regression') return trainingResult.logisticRegression;
    if (activeModelName === 'Decision Tree Classifier') return trainingResult.decisionTree;
    return trainingResult.randomForest;
  }, [activeModelName, trainingResult]);

  const featureImportanceData = useMemo(() => {
    if (!activeModel || !activeModel.metrics?.featureImportance) {
      return [
        { name: 'Internal Marks', Importance: 0.40 },
        { name: 'Study Hours', Importance: 0.30 },
        { name: 'Attendance', Importance: 0.20 },
        { name: 'Assignment Score', Importance: 0.10 }
      ];
    }

    const imp = activeModel.metrics.featureImportance;
    return [
      { name: 'Internal Marks', Importance: Math.round(imp.internalMarks * 100) / 100 },
      { name: 'Study Hours', Importance: Math.round(imp.studyHours * 100) / 100 },
      { name: 'Attendance', Importance: Math.round(imp.attendance * 100) / 100 },
      { name: 'Assignment Score', Importance: Math.round(imp.assignmentScore * 100) / 100 }
    ].sort((a, b) => b.Importance - a.Importance);

  }, [activeModel]);

  // 3. Attendance Bracket bin calculations
  const attendanceBinData = useMemo(() => {
    // Brackets: <60, 60-70, 70-80, 80-90, 90-100
    const bins = {
      '<60%': { pass: 0, fail: 0 },
      '60-70%': { pass: 0, fail: 0 },
      '70-80%': { pass: 0, fail: 0 },
      '80-90%': { pass: 0, fail: 0 },
      '90-100%': { pass: 0, fail: 0 }
    };

    dataset.forEach(item => {
      if (item.attendance < 0) return; // Skip missing pre-processed entries
      let b: keyof typeof bins = '<60%';
      if (item.attendance >= 90) b = '90-100%';
      else if (item.attendance >= 80) b = '80-90%';
      else if (item.attendance >= 70) b = '70-80%';
      else if (item.attendance >= 60) b = '60-70%';

      if (item.result === 'Pass') {
        bins[b].pass++;
      } else {
        bins[b].fail++;
      }
    });

    return Object.keys(bins).map(bin => ({
      range: bin,
      Passed: bins[bin as keyof typeof bins].pass,
      Failed: bins[bin as keyof typeof bins].fail
    }));
  }, [dataset]);

  // 4. Internal Marks bracket bin calculations
  const internalMarksBinData = useMemo(() => {
    // Brackets (out of 50): <20, 20-30, 30-40, 40-50
    const bins = {
      '<20 Marks': { pass: 0, fail: 0 },
      '20-30 Marks': { pass: 0, fail: 0 },
      '30-40 Marks': { pass: 0, fail: 0 },
      '40-50 Marks': { pass: 0, fail: 0 }
    };

    dataset.forEach(item => {
      if (item.internalMarks < 0) return; // Skip preprocessed missing values
      let b: keyof typeof bins = '<20 Marks';
      if (item.internalMarks >= 40) b = '40-50 Marks';
      else if (item.internalMarks >= 30) b = '30-40 Marks';
      else if (item.internalMarks >= 20) b = '20-30 Marks';

      if (item.result === 'Pass') {
        bins[b].pass++;
      } else {
        bins[b].fail++;
      }
    });

    return Object.keys(bins).map(bin => ({
      range: bin,
      Passed: bins[bin as keyof typeof bins].pass,
      Failed: bins[bin as keyof typeof bins].fail
    }));
  }, [dataset]);

  return (
    <div id="visualizations-tab" className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      
      {/* Chart 1: Accuracy Comparison */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-indigo-600" />
            Algorithm Accuracy Comparison Chart
          </h3>
          <p className="text-xs text-slate-500">Benchmark validation score metrics against trained algorithms side-by-side.</p>
        </div>
        
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={accuracyData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <YAxis domain={[60, 100]} tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <Tooltip formatter={(value: any) => [`${value}%`, 'Accuracy']} contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Bar dataKey="Accuracy" radius={[6, 6, 0, 0]} maxBarSize={45}>
                {accuracyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Feature Importance */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            Model Feature Importance ({activeModelName})
          </h3>
          <p className="text-xs text-slate-500">Relative weighting scores calculated based on mathematical coefficient magnitudes or gini purity drops.</p>
        </div>
        
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={featureImportanceData} layout="vertical" margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
              <XAxis type="number" domain={[0, 0.6]} tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" width={100} />
              <Tooltip formatter={(value: any) => [value, 'Relative Importance']} contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Bar dataKey="Importance" fill="#8B5CF6" radius={[0, 4, 4, 0]} maxBarSize={25} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 3: Attendance vs Result */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-blue-600" />
            Attendance Bracket vs Outcome Stack
          </h3>
          <p className="text-xs text-slate-500">Analyzing the correlation: Student counts in Attendance deciles segmented by final results.</p>
        </div>
        
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={attendanceBinData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <YAxis tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Legend wrapperStyle={{ fontSize: '10px' }} />
              <Bar dataKey="Passed" stackId="a" fill="#10B981" radius={[0, 0, 0, 0]} maxBarSize={35} />
              <Bar dataKey="Failed" stackId="a" fill="#EF4444" radius={[4, 4, 0, 0]} maxBarSize={35} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 4: Internal Marks vs Result */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-emerald-600" />
            Internal Evaluation Bracket vs Outcome Stack
          </h3>
          <p className="text-xs text-slate-500">Analyzing correlation: Student outcomes sorted across Continuous Internal Marks ranges.</p>
        </div>
        
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={internalMarksBinData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <YAxis tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" />
              <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Legend wrapperStyle={{ fontSize: '10px' }} />
              <Bar dataKey="Passed" stackId="a" fill="#10B981" radius={[0, 0, 0, 0]} maxBarSize={35} />
              <Bar dataKey="Failed" stackId="a" fill="#EF4444" radius={[4, 4, 0, 0]} maxBarSize={35} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
}
