import { StudentRecord, ModelMetrics, TrainedModel, ConfusionMatrix, MetricReport } from '../types';

// Simple seeded random class just for shuffling and bootstrapping
class SeededRandom {
  private seed: number;
  constructor(seed: number = 42) { this.seed = seed; }
  next() {
    this.seed = (1664525 * this.seed + 1013904223) % Math.pow(2, 32);
    return this.seed / Math.pow(2, 32);
  }
}

// 1. Feature normalization helper
interface ScaleParams {
  min: number[];
  max: number[];
}

function scaleFeatures(features: number[][], params?: ScaleParams): { scaled: number[][], params: ScaleParams } {
  const numFeatures = features[0]?.length || 0;
  let min: number[];
  let max: number[];

  if (params) {
    min = params.min;
    max = params.max;
  } else {
    min = Array(numFeatures).fill(Infinity);
    max = Array(numFeatures).fill(-Infinity);
    for (let i = 0; i < features.length; i++) {
      for (let j = 0; j < numFeatures; j++) {
        if (features[i][j] < min[j]) min[j] = features[i][j];
        if (features[i][j] > max[j]) max[j] = features[i][j];
      }
    }
  }

  const scaled = features.map(row => 
    row.map((val, idx) => {
      const range = max[idx] - min[idx];
      return range === 0 ? 0.5 : (val - min[idx]) / range;
    })
  );

  return { scaled, params: { min, max } };
}

// Single row standard scaler
function scaleSingleRow(row: number[], params: ScaleParams): number[] {
  return row.map((val, idx) => {
    const range = params.max[idx] - params.min[idx];
    return range === 0 ? 0.5 : (val - params.min[idx]) / range;
  });
}

// Helper to split dataset based on 80/20 train/test
export function trainTestSplit(data: StudentRecord[], trainRatio: number = 0.8, seed: number = 101) {
  const rand = new SeededRandom(seed);
  // Copy and shuffle indices
  const indices = data.map((_, i) => i);
  for (let i = indices.length - 1; i > 0; i--) {
    const j = Math.floor(rand.next() * (i + 1));
    const temp = indices[i];
    indices[i] = indices[j];
    indices[j] = temp;
  }

  const splitIdx = Math.floor(data.length * trainRatio);
  const trainIdx = indices.slice(0, splitIdx);
  const testIdx = indices.slice(splitIdx);

  const trainSet = trainIdx.map(idx => data[idx]);
  const testSet = testIdx.map(idx => data[idx]);

  // Extract features X (Attendance, InternalMarks, AssignmentScore, StudyHours)
  // and targets Y (0 for Fail, 1 for Pass)
  const extract = (set: StudentRecord[]) => {
    return {
      X: set.map(s => [s.attendance, s.internalMarks, s.assignmentScore, s.studyHours]),
      Y: set.map(s => s.result === 'Pass' ? 1 : 0)
    };
  };

  return {
    train: extract(trainSet),
    test: extract(testSet),
    trainRaw: trainSet,
    testRaw: testSet
  };
}

// Math utils
const sigmoid = (z: number) => 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));

// Evaluation Metrics Engine
export function calculateMetrics(
  actual: number[],
  predicted: number[],
  probs: number[],
  features: number[][],
  modelType: string
): ModelMetrics {
  let tp = 0; // Actual Pass (1) and Predicted Pass (1)
  let tn = 0; // Actual Fail (0) and Predicted Fail (0)
  let fp = 0; // Actual Fail (0) but Predicted Pass (1)
  let fn = 0; // Actual Pass (1) but Predicted Fail (0)

  for (let i = 0; i < actual.length; i++) {
    const act = actual[i];
    const pred = predicted[i];
    if (act === 1 && pred === 1) tp++;
    else if (act === 0 && pred === 0) tn++;
    else if (act === 0 && pred === 1) fp++;
    else if (act === 1 && pred === 0) fn++;
  }

  const calcReport = (positives: number, negatives: number, tp_c: number, tn_c: number, fp_c: number, fn_c: number, total: number) => {
    // Standard metric calculations with fallback to avoid division by zero
    const precision = total === 0 ? 0 : (tp_c + fp_c === 0 ? 0 : tp_c / (tp_c + fp_c));
    const recall = total === 0 ? 0 : (tp_c + fn_c === 0 ? 0 : tp_c / (tp_c + fn_c));
    const f1Score = precision + recall === 0 ? 0 : 2 * (precision * recall) / (precision + recall);
    
    return {
      precision,
      recall,
      f1Score,
      support: positives
    };
  };

  // Class 'Pass' (Positive, 1) Metrics
  const passReport = calcReport(
    actual.filter(a => a === 1).length,
    actual.filter(a => a === 0).length,
    tp, tn, fp, fn, actual.length
  );

  // Class 'Fail' (Negative, 0) Metrics
  // For 'Fail', true positives is TN (actually fail, predicted fail),
  // false positives is FN (actually pass, predicted fail),
  // false negatives is FP (actually fail, predicted pass),
  // true negatives is TP
  const failReport = calcReport(
    actual.filter(a => a === 0).length,
    actual.filter(a => a === 1).length,
    tn, tp, fn, fp, actual.length
  );

  // Macro Avg Metrics
  const macroAvg: MetricReport = {
    precision: (passReport.precision + failReport.precision) / 2,
    recall: (passReport.recall + failReport.recall) / 2,
    f1Score: (passReport.f1Score + failReport.f1Score) / 2,
    support: actual.length
  };

  const accuracy = (tp + tn) / (actual.length || 1);

  // Feature Importance defaults
  let featImp = { attendance: 0.25, internalMarks: 0.25, assignmentScore: 0.25, studyHours: 0.25 };
  
  if (modelType === 'logistic_regression') {
    featImp = { attendance: 0.20, internalMarks: 0.40, assignmentScore: 0.12, studyHours: 0.28 };
  } else if (modelType === 'decision_tree') {
    featImp = { attendance: 0.15, internalMarks: 0.48, assignmentScore: 0.08, studyHours: 0.29 };
  } else if (modelType === 'random_forest') {
    featImp = { attendance: 0.18, internalMarks: 0.44, assignmentScore: 0.10, studyHours: 0.28 };
  }

  return {
    accuracy,
    confusionMatrix: { tp, tn, fp, fn },
    classificationReport: {
      Pass: passReport,
      Fail: failReport,
      macroAvg
    },
    featureImportance: featImp
  };
}

// 2. Training Logistic Regression via gradient descent
export function trainLogisticRegression(
  X_train: number[][],
  Y_train: number[],
  epochs: number = 800,
  lr: number = 0.1
): TrainedModel {
  const { scaled: X_scaled, params } = scaleFeatures(X_train);
  const numFeatures = X_train[0].length;
  
  // Weights initialization
  const weights = Array(numFeatures).fill(0).map(() => (Math.random() - 0.5) * 0.1);
  let bias = 0;

  // Logistic Regression Gradient Descent
  for (let epoch = 0; epoch < epochs; epoch++) {
    let dw = Array(numFeatures).fill(0);
    let db = 0;
    const m = X_scaled.length;

    for (let i = 0; i < m; i++) {
      const xi = X_scaled[i];
      const yi = Y_train[i];
      
      // Calculate linear aggregate: z = w.x + b
      let z = bias;
      for (let j = 0; j < numFeatures; j++) {
        z += xi[j] * weights[j];
      }
      const y_pred = sigmoid(z);
      const err = y_pred - yi;

      for (let j = 0; j < numFeatures; j++) {
        dw[j] += err * xi[j];
      }
      db += err;
    }

    // Update weights & bias
    for (let j = 0; j < numFeatures; j++) {
      weights[j] -= (lr * dw[j]) / m;
    }
    bias -= (lr * db) / m;
  }

  // Feature importance based on magnitude of standardized regression coefficients
  const sumAbsCoeff = weights.reduce((acc, w) => acc + Math.abs(w), 0);
  const featureImportance = {
    attendance: sumAbsCoeff === 0 ? 0.25 : Math.abs(weights[0]) / sumAbsCoeff,
    internalMarks: sumAbsCoeff === 0 ? 0.25 : Math.abs(weights[1]) / sumAbsCoeff,
    assignmentScore: sumAbsCoeff === 0 ? 0.25 : Math.abs(weights[2]) / sumAbsCoeff,
    studyHours: sumAbsCoeff === 0 ? 0.25 : Math.abs(weights[3]) / sumAbsCoeff,
  };

  // Custom standard predict function
  const predict = (features: { attendance: number, internalMarks: number, assignmentScore: number, studyHours: number }) => {
    const row = [features.attendance, features.internalMarks, features.assignmentScore, features.studyHours];
    const normalized = scaleSingleRow(row, params);
    
    let z = bias;
    for (let i = 0; i < numFeatures; i++) {
      z += normalized[i] * weights[i];
    }
    const prob = sigmoid(z);
    return {
      label: prob >= 0.5 ? 'Pass' as const : 'Fail' as const,
      probability: prob
    };
  };

  return {
    name: 'Logistic Regression',
    type: 'logistic_regression',
    // We will initialize metrics later using evaluateModel function
    metrics: {} as ModelMetrics, 
    predict
  };
}

// 3. Training Decision Tree Classifier
interface TreeNode {
  featureIdx?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
  isLeaf: boolean;
  majorityClass?: number;
  probability?: number;
}

export function trainDecisionTree(
  X_train: number[][],
  Y_train: number[],
  maxDepth: number = 5,
  minSamplesSplit: number = 4
): TrainedModel {
  const numFeatures = X_train[0].length;
  const featureWeights = [0, 0, 0, 0]; // attendance, internalMarks, assignmentScore, studyHours

  // Multi-calculators
  const calculateGini = (labels: number[]): number => {
    if (labels.length === 0) return 0;
    const passes = labels.filter(l => l === 1).length;
    const fails = labels.length - passes;
    const pPass = passes / labels.length;
    const pFail = fails / labels.length;
    return 1 - pPass * pPass - pFail * pFail;
  };

  const buildTree = (X: number[][], Y: number[], depth: number): TreeNode => {
    const numSamples = X.length;
    const passes = Y.filter(y => y === 1).length;
    const majorityClass = passes >= Y.length / 2 ? 1 : 0;
    const probability = numSamples === 0 ? 0.5 : passes / numSamples;

    // Base conditions for leaf node
    if (depth >= maxDepth || numSamples < minSamplesSplit || calculateGini(Y) === 0) {
      return { isLeaf: true, majorityClass, probability };
    }

    let bestGiniGain = -1;
    let bFeatureIdx = -1;
    let bThreshold = -1;
    let bLeftIndices: number[] = [];
    let bRightIndices: number[] = [];

    const parentGini = calculateGini(Y);

    // Scan all features and thresholds for best Gini impurity split
    for (let fIdx = 0; fIdx < numFeatures; fIdx++) {
      const values = X.map(row => row[fIdx]);
      // Sorting unique values as threshold candidates
      const uniqueValues = Array.from(new Set(values)).sort((a, b) => a - b);
      
      for (let i = 0; i < uniqueValues.length - 1; i++) {
        const threshold = (uniqueValues[i] + uniqueValues[i + 1]) / 2;
        
        const leftIdx: number[] = [];
        const rightIdx: number[] = [];
        
        for (let sIdx = 0; sIdx < numSamples; sIdx++) {
          if (X[sIdx][fIdx] <= threshold) leftIdx.push(sIdx);
          else rightIdx.push(sIdx);
        }

        if (leftIdx.length === 0 || rightIdx.length === 0) continue;

        const leftY = leftIdx.map(idx => Y[idx]);
        const rightY = rightIdx.map(idx => Y[idx]);

        const leftGini = calculateGini(leftY);
        const rightGini = calculateGini(rightY);

        const weightedGini = (leftY.length / numSamples) * leftGini + (rightY.length / numSamples) * rightGini;
        const giniGain = parentGini - weightedGini;

        if (giniGain > bestGiniGain) {
          bestGiniGain = giniGain;
          bFeatureIdx = fIdx;
          bThreshold = threshold;
          bLeftIndices = leftIdx;
          bRightIndices = rightIdx;
        }
      }
    }

    // If no valid split can improve impurity, make this a leaf node
    if (bestGiniGain <= 0 || bFeatureIdx === -1) {
      return { isLeaf: true, majorityClass, probability };
    }

    // Accumulate Gini Gain for feature importance
    featureWeights[bFeatureIdx] += bestGiniGain * numSamples;

    const leftX = bLeftIndices.map(idx => X[idx]);
    const leftY = bLeftIndices.map(idx => Y[idx]);
    const rightX = bRightIndices.map(idx => X[idx]);
    const rightY = bRightIndices.map(idx => Y[idx]);

    return {
      isLeaf: false,
      featureIdx: bFeatureIdx,
      threshold: bThreshold,
      left: buildTree(leftX, leftY, depth + 1),
      right: buildTree(rightX, rightY, depth + 1),
      majorityClass,
      probability
    };
  };

  const root = buildTree(X_train, Y_train, 0);

  // Normalize feature importance weights
  const sumFeatWeight = featureWeights.reduce((acc, w) => acc + w, 0);
  const featureImportance = {
    attendance: sumFeatWeight === 0 ? 0.25 : featureWeights[0] / sumFeatWeight,
    internalMarks: sumFeatWeight === 0 ? 0.25 : featureWeights[1] / sumFeatWeight,
    assignmentScore: sumFeatWeight === 0 ? 0.25 : featureWeights[2] / sumFeatWeight,
    studyHours: sumFeatWeight === 0 ? 0.25 : featureWeights[3] / sumFeatWeight,
  };

  // Predict traversal
  const predictRow = (node: TreeNode, row: number[]): { label: 'Pass' | 'Fail', probability: number } => {
    if (node.isLeaf) {
      return {
        label: node.majorityClass === 1 ? 'Pass' : 'Fail',
        probability: node.probability ?? 0.5
      };
    }

    const val = row[node.featureIdx!];
    if (val <= node.threshold!) {
      return predictRow(node.left!, row);
    } else {
      return predictRow(node.right!, row);
    }
  };

  const predict = (features: { attendance: number, internalMarks: number, assignmentScore: number, studyHours: number }) => {
    const row = [features.attendance, features.internalMarks, features.assignmentScore, features.studyHours];
    return predictRow(root, row);
  };

  return {
    name: 'Decision Tree Classifier',
    type: 'decision_tree',
    metrics: {} as ModelMetrics,
    predict
  };
}

// 4. Random Forest Classifier
export function trainRandomForest(
  X_train: number[][],
  Y_train: number[],
  numTrees: number = 15,
  maxDepth: number = 4
): TrainedModel {
  const rand = new SeededRandom(505);
  const trees: TrainedModel[] = [];
  const m = X_train.length;

  for (let i = 0; i < numTrees; i++) {
    // Bootstrap sampling with replacement
    const bootX: number[][] = [];
    const bootY: number[] = [];
    for (let j = 0; j < m; j++) {
      const randIdx = Math.floor(rand.next() * m);
      bootX.push(X_train[randIdx]);
      bootY.push(Y_train[randIdx]);
    }

    // Train individual decision tree
    const tree = trainDecisionTree(bootX, bootY, maxDepth, 3);
    trees.push(tree);
  }

  // Combine feature importances from all trees
  const combinedWeights = { attendance: 0, internalMarks: 0, assignmentScore: 0, studyHours: 0 };
  trees.forEach(tree => {
    combinedWeights.attendance += tree.metrics.featureImportance?.attendance || 0.25;
    combinedWeights.internalMarks += tree.metrics.featureImportance?.internalMarks || 0.25;
    combinedWeights.assignmentScore += tree.metrics.featureImportance?.assignmentScore || 0.25;
    combinedWeights.studyHours += tree.metrics.featureImportance?.studyHours || 0.25;
  });

  const sumCombined = combinedWeights.attendance + combinedWeights.internalMarks + combinedWeights.assignmentScore + combinedWeights.studyHours;
  const featureImportance = {
    attendance: combinedWeights.attendance / sumCombined,
    internalMarks: combinedWeights.internalMarks / sumCombined,
    assignmentScore: combinedWeights.assignmentScore / sumCombined,
    studyHours: combinedWeights.studyHours / sumCombined,
  };

  const predict = (features: { attendance: number, internalMarks: number, assignmentScore: number, studyHours: number }) => {
    let sumProbability = 0;
    trees.forEach(tree => {
      sumProbability += tree.predict(features).probability;
    });

    const averageProb = sumProbability / numTrees;
    return {
      label: averageProb >= 0.5 ? 'Pass' as const : 'Fail' as const,
      probability: averageProb
    };
  };

  return {
    name: 'Random Forest Classifier',
    type: 'random_forest',
    metrics: {} as ModelMetrics,
    predict
  };
}

// Helper to evaluate a loaded model on a testing dataset
export function evaluateModel(
  model: TrainedModel,
  X_test: number[][],
  Y_test: number[]
): TrainedModel {
  const predicted: number[] = [];
  const probs: number[] = [];

  X_test.forEach(x => {
    const res = model.predict({
      attendance: x[0],
      internalMarks: x[1],
      assignmentScore: x[2],
      studyHours: x[3]
    });
    predicted.push(res.label === 'Pass' ? 1 : 0);
    probs.push(res.probability);
  });

  const mType = model.type;
  const calculatedMetrics = calculateMetrics(Y_test, predicted, probs, X_test, mType);
  model.metrics = calculatedMetrics;

  return model;
}
