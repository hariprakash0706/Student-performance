import { StudentRecord } from '../types';

// Linear Congruential Generator for reproducible seed-based randomness
class SeededRandom {
  private seed: number;

  constructor(seed: number = 42) {
    this.seed = seed;
  }

  // Returns pseudo-random number in [0, 1)
  next(): number {
    const a = 1664525;
    const c = 1013904223;
    const m = Math.pow(2, 32);
    this.seed = (a * this.seed + c) % m;
    return this.seed / m;
  }

  // Returns box-muller normal distributed random number
  nextGaussian(mean: number, stdDev: number): number {
    const u1 = this.next() || 0.0001; // Avoid log(0)
    const u2 = this.next();
    const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);
    return mean + stdDev * randStdNormal;
  }

  // Random integer between min and max inclusive
  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }
}

export function generateSampleDataset(seed: number = 2026, addAnomalies: boolean = false): StudentRecord[] {
  const rand = new SeededRandom(seed);
  const data: StudentRecord[] = [];

  for (let i = 1; i <= 500; i++) {
    // Attendance: Mean 78%, SD 12, clamped between 30 and 100
    let attendance = Math.round(rand.nextGaussian(78, 12));
    attendance = Math.max(30, Math.min(100, attendance));

    // Internal Marks: Mean 30, SD 8, clamped between 0 and 50
    let internalMarks = Math.round(rand.nextGaussian(30, 8));
    internalMarks = Math.max(0, Math.min(50, internalMarks));

    // Assignment Score: Mean 72, SD 14, clamped between 0 and 100
    let assignmentScore = Math.round(rand.nextGaussian(72, 14));
    assignmentScore = Math.max(0, Math.min(100, assignmentScore));

    // Study Hours: Mean 4.8 hr/day, SD 2.1, clamped between 0.5 and 12
    let studyHours = Math.round(rand.nextGaussian(4.8, 2.1) * 10) / 10;
    studyHours = Math.max(0.5, Math.min(12, studyHours));

    // Sigmoid probability function to determine Result
    // Higher attendance, internals, assignments, and study hours improve pass chance
    const z = 0.09 * attendance + 0.16 * internalMarks + 0.04 * assignmentScore + 0.45 * studyHours - 18.0;
    const p = 1 / (1 + Math.exp(-z));
    
    // Add small noise to make it realistic
    const threshold = p + (rand.next() - 0.5) * 0.1;
    const result = threshold >= 0.5 ? 'Pass' : 'Fail';

    data.push({
      id: i,
      attendance,
      internalMarks,
      assignmentScore,
      studyHours,
      result,
    });
  }

  if (addAnomalies) {
    // Inject some duplicates (exactly 8 duplicate rows)
    const duplicatesIndices = [12, 45, 120, 230, 311, 388, 412, 475];
    duplicatesIndices.forEach((idx, offset) => {
      if (idx < data.length) {
        // Create duplicate with new id, but exact same features
        const source = data[idx];
        data.push({
          ...source,
          id: 500 + offset + 1, // New ID to keep key unique, but values are duplicate
        });
      }
    });

    // Inject some nulls / missing values (e.g. attendance as NaN / negative anomaly indicating missing, or study hours as -1)
    // We will handle them during data cleaning
    const missingIndices = [5, 25, 76, 150, 203, 301, 350, 420];
    missingIndices.forEach((idx) => {
      if (idx < data.length) {
        // We set values to null / NaN represented values
        if (idx % 4 === 0) {
          data[idx].attendance = -1; // Indicates missing percentage
        } else if (idx % 4 === 1) {
          data[idx].internalMarks = -1; // Indicates missing marks
        } else if (idx % 4 === 2) {
          data[idx].assignmentScore = -1; // Indicates missing assignments
        } else {
          data[idx].studyHours = -1; // Indicates missing study hours
        }
      }
    });
  }

  return data;
}

export function cleanDataset(data: StudentRecord[]): {
  cleanedData: StudentRecord[];
  stats: {
    originalCount: number;
    cleanedCount: number;
    missingValuesHandled: number;
    duplicatesRemoved: number;
  };
} {
  const originalCount = data.length;
  let missingValuesHandled = 0;
  let duplicatesRemoved = 0;

  // 1. Calculate medians of valid values to fill missing values
  const validAttendances = data.filter(d => d.attendance >= 0).map(d => d.attendance);
  const validInternals = data.filter(d => d.internalMarks >= 0).map(d => d.internalMarks);
  const validAssignments = data.filter(d => d.assignmentScore >= 0).map(d => d.assignmentScore);
  const validStudyHours = data.filter(d => d.studyHours >= 0).map(d => d.studyHours);

  const median = (arr: number[]) => {
    if (arr.length === 0) return 0;
    const sorted = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  };

  const medianAttendance = Math.round(median(validAttendances));
  const medianInternal = Math.round(median(validInternals));
  const medianAssignment = Math.round(median(validAssignments));
  const medianStudyHours = Math.round(median(validStudyHours) * 10) / 10;

  // 2. Clear duplicates & handle missing numeric anomalies
  const uniqueRows = new Map<string, StudentRecord>();
  
  data.forEach(row => {
    // Generate signature of the features (excluding ID and Result)
    let att = row.attendance;
    let inter = row.internalMarks;
    let assign = row.assignmentScore;
    let hours = row.studyHours;

    let wasMissing = false;

    if (att < 0) {
      att = medianAttendance;
      wasMissing = true;
    }
    if (inter < 0) {
      inter = medianInternal;
      wasMissing = true;
    }
    if (assign < 0) {
      assign = medianAssignment;
      wasMissing = true;
    }
    if (hours < 0) {
      hours = medianStudyHours;
      wasMissing = true;
    }

    if (wasMissing) {
      missingValuesHandled++;
    }

    // Use a string representation of standard qualities to detect true duplicate values in features
    const signature = `${att}_${inter}_${assign}_${hours}_${row.result}`;
    
    // If signature exists, we skip it as a duplicate record
    if (uniqueRows.has(signature)) {
      duplicatesRemoved++;
    } else {
      uniqueRows.set(signature, {
        id: row.id,
        attendance: att,
        internalMarks: inter,
        assignmentScore: assign,
        studyHours: hours,
        result: row.result
      });
    }
  });

  // Reconstruct list from the map and sort back by ID
  const cleanedData = Array.from(uniqueRows.values()).sort((a, b) => a.id - b.id);

  return {
    cleanedData,
    stats: {
      originalCount,
      cleanedCount: cleanedData.length,
      missingValuesHandled,
      duplicatesRemoved,
    }
  };
}
