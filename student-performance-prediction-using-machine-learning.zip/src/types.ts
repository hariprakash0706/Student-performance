export interface StudentRecord {
  id: number;
  attendance: number;       // Percentage (0 - 100)
  internalMarks: number;    // Marks (0 - 50)
  assignmentScore: number; // Score (0 - 100)
  studyHours: number;       // Hours per day (0 - 12)
  result: 'Pass' | 'Fail';
}

export interface CleaningStats {
  originalCount: number;
  cleanedCount: number;
  missingValuesHandled: number;
  duplicatesRemoved: number;
}

export interface ConfusionMatrix {
  tp: number; // True Positive (Pass predicted as Pass)
  tn: number; // True Negative (Fail predicted as Fail)
  fp: number; // False Positive (Fail predicted as Pass)
  fn: number; // False Negative (Pass predicted as Fail)
}

export interface MetricReport {
  precision: number;
  recall: number;
  f1Score: number;
  support: number;
}

export interface ModelMetrics {
  accuracy: number;
  confusionMatrix: ConfusionMatrix;
  classificationReport: {
    Pass: MetricReport;
    Fail: MetricReport;
    macroAvg: MetricReport;
  };
  featureImportance: {
    attendance: number;
    internalMarks: number;
    assignmentScore: number;
    studyHours: number;
  };
}

export interface TrainedModel {
  name: string;
  type: 'logistic_regression' | 'decision_tree' | 'random_forest';
  metrics: ModelMetrics;
  predict: (features: {
    attendance: number;
    internalMarks: number;
    assignmentScore: number;
    studyHours: number;
  }) => { label: 'Pass' | 'Fail'; probability: number };
}

export interface TrainingResult {
  logisticRegression: TrainedModel | null;
  decisionTree: TrainedModel | null;
  randomForest: TrainedModel | null;
  bestModelName: string;
  isTraining: boolean;
}
