import React, { useState } from 'react';
import { StudentRecord, TrainingResult } from './types';
import { generateSampleDataset } from './utils/dataGenerator';
import DatasetExplorer from './components/DatasetExplorer';
import ModelTrainer from './components/ModelTrainer';
import Visualizations from './components/Visualizations';
import PredictorPlayground from './components/PredictorPlayground';
import DocumentationTab from './components/DocumentationTab';
import { 
  GraduationCap, 
  Database, 
  Cpu, 
  LineChart, 
  CheckCircle2, 
  BookOpen, 
  Award, 
  ShieldCheck, 
  PlayCircle,
  HelpCircle,
  Code2
} from 'lucide-react';

export default function App() {
  // 1. Core shared dataset state
  const [dataset, setDataset] = useState<StudentRecord[]>(() => {
    return generateSampleDataset(1998, false); // Standard 500 clean dataset initially
  });
  const [originalCount, setOriginalCount] = useState(500);
  const [cleaningStats, setCleaningStats] = useState<any | null>(null);

  // 2. Core shared model training state
  const [trainingResult, setTrainingResult] = useState<TrainingResult>({
    logisticRegression: null,
    decisionTree: null,
    randomForest: null,
    bestModelName: 'Random Forest Classifier',
    isTraining: false
  });

  // 3. Current selected active algorithm for charts / predictions
  const [activeModelName, setActiveModelName] = useState('Random Forest Classifier');

  // 4. Current navigation tab
  const [activeTab, setActiveTab ] = useState<'dataset' | 'trainer' | 'charts' | 'predict' | 'report'>('dataset');

  // Compute stats for overview bar
  const activeModelAccuracy = React.useMemo(() => {
    if (activeModelName === 'Logistic Regression' && trainingResult.logisticRegression) {
      return (trainingResult.logisticRegression.metrics.accuracy * 100).toFixed(1) + '%';
    }
    if (activeModelName === 'Decision Tree Classifier' && trainingResult.decisionTree) {
      return (trainingResult.decisionTree.metrics.accuracy * 100).toFixed(1) + '%';
    }
    if (activeModelName === 'Random Forest Classifier' && trainingResult.randomForest) {
      return (trainingResult.randomForest.metrics.accuracy * 100).toFixed(1) + '%';
    }
    return 'Untrained';
  }, [activeModelName, trainingResult]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased selection:bg-indigo-500 selection:text-white pb-12">
      
      {/* Header bar */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            
            <div className="flex items-center gap-3.5">
              <span className="p-3 bg-indigo-600 text-white rounded-2xl shadow-md shadow-indigo-600/10">
                <GraduationCap className="w-7 h-7" />
              </span>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight leading-none">
                  Student Performance Prediction Using Machine Learning
                </h1>
                <p className="text-xs text-slate-500 mt-1 md:mt-1.5 font-medium flex items-center gap-1">
                  <span>Educational progression modeling & predictive analytics dashboard</span>
                  <span className="text-slate-300">•</span>
                  <span className="text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-md font-semibold text-[10px]">Academic Sandbox</span>
                </p>
              </div>
            </div>

            {/* Quick Session Stats */}
            <div className="flex items-center gap-2 sm:gap-4 self-start md:self-auto bg-slate-50 border border-slate-200/60 p-1.5 rounded-xl font-mono text-xs">
              <div className="px-2.5 py-1 text-center border-r border-slate-200">
                <span className="block text-[9px] uppercase font-bold text-slate-400">Total Samples</span>
                <span className="font-bold text-slate-800">{dataset.length}</span>
              </div>
              <div className="px-2.5 py-1 text-center border-r border-slate-200">
                <span className="block text-[9px] uppercase font-bold text-slate-400">Selected model</span>
                <span className="font-bold text-indigo-600">
                  {activeModelName === 'Logistic Regression' ? 'Log Reg' : activeModelName === 'Decision Tree Classifier' ? 'D-Tree' : 'R-Forest'}
                </span>
              </div>
              <div className="px-2.5 py-1 text-center">
                <span className="block text-[9px] uppercase font-bold text-slate-400">Test Accuracy</span>
                <span className="font-bold text-emerald-600">{activeModelAccuracy}</span>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="space-y-6">

          {/* Quick Informative Hero Intro */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg shadow-indigo-950/20">
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-2xl -ml-20 -mb-20"></div>

            <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <span className="px-2.5 py-1 bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 rounded-full text-[10px] font-bold tracking-widest uppercase">
                  Machine Learning Pipeline
                </span>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight">
                  Predict student outcomes using three standard classifiers
                </h2>
                <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Step through the machine learning pipeline in real time. We simulate raw data structures, clean values, train classification algorithms, plot accuracy vs feature rating distributions, and render predictive outcomes.
                </p>
              </div>

              <div className="flex flex-wrap md:flex-nowrap gap-3 shrink-0">
                <button
                  id="nav-to-inference-btn"
                  onClick={() => setActiveTab('predict')}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-700/15 transition-all flex items-center gap-1.5"
                >
                  <PlayCircle className="w-4 h-4" />
                  Test Student Predictions
                </button>
                <button
                  id="nav-to-report-btn"
                  onClick={() => setActiveTab('report')}
                  className="px-4 py-2 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/10 hover:border-white/20 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <Code2 className="w-4 h-4" />
                  Get Python Code
                </button>
              </div>
            </div>
          </div>

          {/* Nav Tab Bar */}
          <div className="flex items-center gap-1 bg-white/80 backdrop-blur-md border border-slate-200 p-1 rounded-2xl overflow-x-auto custom-scrollbar shadow-xs">
            <button
              id="tab-dataset-btn"
              onClick={() => setActiveTab('dataset')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl shrink-0 transition-colors ${
                activeTab === 'dataset'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Database className="w-4 h-4" />
              1. Exploratory Data Pipeline & Cleaning
            </button>
            <button
              id="tab-trainer-btn"
              onClick={() => setActiveTab('trainer')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl shrink-0 transition-colors ${
                activeTab === 'trainer'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Cpu className="w-4 h-4" />
              2. Fit Algorithms & Hyperparameters
            </button>
            <button
              id="tab-charts-btn"
              onClick={() => setActiveTab('charts')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl shrink-0 transition-colors ${
                activeTab === 'charts'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <LineChart className="w-4 h-4" />
              3. Diagnostic Visualization Plots
            </button>
            <button
              id="tab-predict-btn"
              onClick={() => setActiveTab('predict')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl shrink-0 transition-colors ${
                activeTab === 'predict'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              4. Direct Student Inference
            </button>
            <button
              id="tab-report-btn"
              onClick={() => setActiveTab('report')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl shrink-0 transition-colors ${
                activeTab === 'report'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              5. Academic Project Report & Python Code
            </button>
          </div>

          {/* Dynamic Rendered Component Portion */}
          <div className="transition-opacity duration-200">
            {activeTab === 'dataset' && (
              <DatasetExplorer
                dataset={dataset}
                setDataset={setDataset}
                originalCount={originalCount}
                setOriginalCount={setOriginalCount}
                cleaningStats={cleaningStats}
                setCleaningStats={setCleaningStats}
              />
            )}

            {activeTab === 'trainer' && (
              <ModelTrainer
                dataset={dataset}
                trainingResult={trainingResult}
                setTrainingResult={setTrainingResult}
                activeModelName={activeModelName}
                setActiveModelName={setActiveModelName}
              />
            )}

            {activeTab === 'charts' && (
              <Visualizations
                dataset={dataset}
                trainingResult={trainingResult}
                activeModelName={activeModelName}
              />
            )}

            {activeTab === 'predict' && (
              <PredictorPlayground
                trainingResult={trainingResult}
                activeModelName={activeModelName}
                setActiveModelName={setActiveModelName}
              />
            )}

            {activeTab === 'report' && (
              <DocumentationTab />
            )}
          </div>

        </div>
      </main>

      {/* Footer block */}
      <footer className="mt-12 bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 font-medium">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-2">
          <p>
            Student Success Predictor Sandbox • Designed for Academic Evaluation
          </p>
          <p className="text-[10px] text-slate-350">
            Engineered using standard Javascript mathematical vector loops for client-side model fitting. Plots compiled with Recharts SVG rendering libraries.
          </p>
        </div>
      </footer>

    </div>
  );
}
